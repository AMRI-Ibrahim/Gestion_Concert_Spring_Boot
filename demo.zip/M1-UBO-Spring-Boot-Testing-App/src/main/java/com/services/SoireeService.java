package com.services;

import com.dtos.SalleDto;
import com.dtos.SoireeDto;

import java.util.List;

public interface SoireeService {
    SoireeDto saveSoiree(SoireeDto SoireeDto);


    SoireeDto getSoireeById(Long soireeId);


    boolean deleteSoiree(Long soireeId);


    List<SoireeDto> getAllSoirees();
}
