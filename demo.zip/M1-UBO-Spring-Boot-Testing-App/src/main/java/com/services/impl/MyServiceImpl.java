package com.services.impl;

import com.dtos.MyDTO;
import com.entities.MyEntity;
import com.repositories.MyRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service("myservice")
public class MyServiceImpl {

    @Autowired
    private MyRepository myRepository;

    public List<MyDTO> getAllDocuments() {
        List<MyEntity> entities = myRepository.findAll();
        return entities.stream().map(this::convertEntityToDTO).collect(Collectors.toList());
    }

    private MyDTO convertEntityToDTO(MyEntity entity) {
        MyDTO dto = new MyDTO();
        dto.setId(entity.getId());
        dto.setName(entity.getName());
        dto.setDescription(entity.getDescription());
        return dto;
    }

}
