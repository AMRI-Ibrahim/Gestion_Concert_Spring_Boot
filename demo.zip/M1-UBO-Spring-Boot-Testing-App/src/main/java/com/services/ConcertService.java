package com.services;

import com.dtos.ConcertDto;
import com.dtos.DogDto;

import java.util.List;

public interface ConcertService {

    ConcertDto saveConcert(ConcertDto concertDto);


    ConcertDto getConcertById(Long concertId);


    boolean deleteConcert(Long concertId);


    List<ConcertDto> getAllConcerts();

}