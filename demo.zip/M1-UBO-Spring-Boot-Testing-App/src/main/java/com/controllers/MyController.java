package com.controllers;

import com.dtos.MyDTO;
import com.services.MyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api")
public class MyController {
    private MyService myService;

    @GetMapping("/documents")
    public List<MyDTO> getAllDocuments() {
        return myService.getAllDocuments();
    }
}
